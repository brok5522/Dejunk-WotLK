Dejunk-WotLK 0.16.55-dev - COMPATIBILITY PORT DEVELOPMENT BUILD
Original WoW 3.3.5a / build 12340 / Interface 30300 only.
Original-client testing is pending; this is not the complete addon.
Extract so Interface/AddOns/Dejunk-WotLK/Dejunk-WotLK.toc exists.
/djw status | /djw profiles list|create|switch | /djw lists | /djw preview sell|destroy | /djw report
The slot command reads only the chosen bag slot. The report can be copied.
Merchant sell, auto repair, loot and confirmed destroy actions use a guarded legacy API adapter.
Original-client acceptance testing is pending; never test deletion with valuable inventory.
Disable in the AddOns menu or remove only this addon folder to uninstall.
Code is independently written; upstream design reference: moody/Dejunk
commit 04bafd5e411441ef5b51bb8ed10d208f2d7758f5 (MIT).
Dejunk UI icons are upstream artwork, copyright moody, under the MIT License in assets/LICENSE.txt.
No upstream code or Blizzard FrameXML is bundled.
