Dejunk-WotLK 0.16.17-dev - COMPATIBILITY PORT DEVELOPMENT BUILD
Original WoW 3.3.5a / build 12340 / Interface 30300 only.
Original-client testing is pending; this is not the complete addon.
Extract so Interface/AddOns/Dejunk-WotLK/Dejunk-WotLK.toc exists.
/djw status | /djw profiles list|create|switch | /djw lists | /djw preview sell|destroy | /djw report
The slot command reads only the chosen bag slot. The report can be copied.
Seller/repair/destruction services are simulation-only. No game selling, repair, deletion or item use is connected.
Disable in the AddOns menu or remove only this addon folder to uninstall.
Code is independently written; upstream design reference: moody/Dejunk
commit 04bafd5e411441ef5b51bb8ed10d208f2d7758f5 (MIT).
No upstream code, libraries, artwork or Blizzard FrameXML are bundled.
